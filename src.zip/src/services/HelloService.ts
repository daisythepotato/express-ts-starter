export const getHelloMessage = (): string => {
  return 'Hello World!';
}; // 에러가 발생할 가능성이 없기에 throw가 필요하지 않음